
/* =====================================
   Cartoon Episode Watch Page
===================================== */

/* Get cartoon name from URL */
const params = new URLSearchParams(window.location.search);

const cartoon = (params.get("cartoon") || "")
    .trim()
    .replace(/\.$/, "");


/* =====================================
   Cartoon Episodes
===================================== */

const episodes = {

    /* ---------- MOTU PATLU ---------- */
    "Motu Patlu": [
        {
            title: "Motu Patlu - Episode 1",
            video: ""
        },
        {
            title: "Motu Patlu - Episode 2",
            video: ""
        },
        {
            title: "Motu Patlu - Episode 3",
            video: "vYM9wrC-Kmw"
        },
        {
            title: "Motu Patlu - Episode 4",
            video: ""
        },
        {
            title: "Motu Patlu - Episode 5",
            video: "z37NsUwRMVo"
        }
    ],


    /* ---------- OGGY ---------- */
    "Oggy and the Cockroaches": [
        {
            title: "Oggy and the Cockroaches - Episode 1",
            video: "lRKciQGYwjo"
        },
        {
            title: "Oggy and the Cockroaches - Episode 2",
            video: "GDSgU_wmREY"
        },
        {
            title: "Oggy and the Cockroaches - Episode 3",
            video: "4auOwokj2qg"
        },
        {
            title: "Oggy and the Cockroaches - Episode 4",
            video: "aqcUTX2LsYA"
        },
        {
            title: "Oggy and the Cockroaches - Episode 5",
            video: "LSQsNeH2WLc"
        }
    ],


    /* ---------- FROZEN ---------- */
    "Frozen": [
        {
            title: "Frozen - Episode 1",
            video: "L0MK7qz13bU"
        },
        {
            title: "Frozen - Episode 2",
            video: "Luaxm9O1IVU"
        },
        {
            title: "Frozen - Episode 3",
            video: "Hfhz-gU9GuQ"
        },
        {
            title: "Frozen - Episode 4",
            video: "IND11jdzUXE"
        }
    ],


    /* ---------- WINNIE THE POOH ---------- */
    "Winnie the Pooh": [
        {
            title: "Winnie the Pooh - Episode 1",
            video: "bdTd1PDOc0uZl-VL"
        },
        {
            title: "Winnie the Pooh - Episode 2",
            video: "nWvG8bmCTsm8tn3u"
        },
        {
            title: "Winnie the Pooh - Episode 3",
            video: "DfYjFEHDCVAWFcrA"
        },
        {
            title: "Winnie the Pooh - Episode 4",
            video: "cGHiSMoUwxoE_iin"
        }
    ],
    /* ---------- RAPUNZEL ---------- *
    "Rapunzel": [
        {
            title: "Rapunzel - Episode 1",
            video: "BvHRNwjcUrU"
        },
        {
            title: "Rapunzel - Episode 2",
            video: "_tOU5Le9YiY"
        },
        {
            title: "Rapunzel - Episode 3",
            video: "kVe_Jm6uCgw"
        },
        {
            title: "Rapunzel - Episode 4",
            video: "JLsz5vV3Q08"
        }
    ],


    /* ---------- SHINCHAN ---------- */
    "Shinchan": [
        {
            title: "Shinchan - Episode 1",
            video: "r8R7dI7hNIk"
        },
        {
            title: "Shinchan - Episode 2",
            video: "wY-v0XZAumA"
        },
        {
            title: "Shinchan - Episode 3",
            video: "sx_Jhqz63s4"
        },
        {
            title: "Shinchan - Episode 4",
            video: "fyBCOZ7PteU"
        }
    ],


    /* ---------- NINJA HATTORI ---------- */
    "Ninja Hattori": [
        {
            title: "Ninja Hattori - Episode 1",
            video: "1RK1b8zGXPI"
        },
        {
            title: "Ninja Hattori - Episode 2",
            video: "3CZTng_4ark"
        },
        {
            title: "Ninja Hattori - Episode 3",
            video: "CmCEaV28pq4"
        },
        {
            title: "Ninja Hattori - Episode 4",
            video: "cIUY4gknMPY"
        }
    ],


    /* ---------- DORAEMON ---------- */
    "Doraemon": [
        {
            title: "Doraemon - Episode 1",
            video: ""
        },
        {
            title: "Doraemon - Episode 2",
            video: ""
        },
        {
            title: "Doraemon - Episode 3",
            video: ""
        },
        {
            title: "Doraemon - Episode 4",
            video: ""
        }
    ],


    /* ---------- BEN 10 ---------- */
    "Ben 10": [
        {
            title: "Ben 10 - Episode 1",
            video: ""
        },
        {
            title: "Ben 10 - Episode 2",
            video: ""
        },
        {
            title: "Ben 10 - Episode 3",
            video: ""
        },
        {
            title: "Ben 10 - Episode 4",
            video: ""
        }
    ],


    /* ---------- MASHA AND THE BEAR ---------- */
    "Masha and the Bear": [
        {
            title: "Masha and the Bear - Episode 1",
            video: ""
        },
        {
            title: "Masha and the Bear - Episode 2",
            video: ""
        },
        {
            title: "Masha and the Bear - Episode 3",
            video: ""
        },
        {
            title: "Masha and the Bear - Episode 4",
            video: ""
        }
    ]
};


/* =====================================
   Cartoon Title
===================================== */

document.getElementById("cartoonTitle").innerHTML =
    `🎬 ${cartoon || "Cartoon"} Episodes`;


/* =====================================
   Display Episodes
===================================== */

let output = "";

if (episodes[cartoon]) {

    episodes[cartoon].forEach((episode, index) => {

        output += `
        <div class="col-lg-4 col-md-6">
            <div class="card cartoon-card h-100 shadow">
                <div class="card-body text-center">

                    <h4>
                        ${episode.title}
                    </h4>

                    <p>
                        Enjoy this exciting cartoon episode!
                    </p>

                    ${
                        episode.video
                        ?
                        `<button
                            class="btn btn-warning"
                            onclick="watchEpisode(${index})">
                            ▶ Watch Now
                        </button>`
                        :
                        `<button
                            class="btn btn-secondary"
                            disabled>
                            Video Not Added
                        </button>`
                    }

                </div>
            </div>
        </div>
        `;
    });

}
else {

    output = `
    <div class="col-12 text-center">

        <h3 class="text-danger">
            Cartoon not found 😢
        </h3>

        <a
            href="cartoons.html"
            class="btn btn-primary mt-3">
            ← Back to Cartoons
        </a>

    </div>
    `;
}


/* Put episodes on page */
document.getElementById("episodes").innerHTML = output;


/* =====================================
   Watch Episode
===================================== */

function watchEpisode(index) {

    const episode = episodes[cartoon][index];

    if (!episode.video) {
        alert("Video is not available yet.");
        return;
    }


    /* Episode title */
    document.getElementById("episodeTitle").innerHTML =
        `▶ ${episode.title}`;


    /* YouTube Embed URL */
    const embedURL =
        `https://www.youtube.com/embed/${episode.video}?rel=0`;


    /* Normal YouTube URL */
    const youtubeURL =
        `https://www.youtube.com/watch?v=${episode.video}`;


    /* Set iframe */
    const player =
        document.getElementById("youtubePlayer");

    player.src = embedURL;


    /* Set fallback YouTube button */
    const youtubeLink =
        document.getElementById("youtubeLink");

    youtubeLink.href = youtubeURL;


    /* Hide fallback initially */
    document.getElementById("youtubeFallback").style.display =
        "none";


    /* Scroll to player */
    document.getElementById("episodeTitle").scrollIntoView({
        behavior: "smooth",
        block: "center"
    });
}


/* =====================================
   YouTube Error / Fallback
===================================== */

document
    .getElementById("youtubePlayer")
    .addEventListener("load", function () {

        /*
           The iframe load event alone cannot reliably
           tell whether YouTube allows embedding.

           The fallback button is therefore kept available
           below the player whenever an episode is selected.
        */

        document.getElementById("youtubeFallback").style.display =
            "block";
    });