/* =====================================
   Cartoon World Contact Form
===================================== */

const contactForm = document.getElementById("contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", async function (event) {

        event.preventDefault();


        /* ================= GET VALUES ================= */

        const name =
            document.getElementById("contactName").value.trim();

        const email =
            document.getElementById("contactEmail").value.trim();

        const message =
            document.getElementById("contactMessage").value.trim();


        /* ================= ERROR ELEMENTS ================= */

        const nameError =
            document.getElementById("contactNameError");

        const emailError =
            document.getElementById("contactEmailError");

        const messageError =
            document.getElementById("contactMessageError");

        const success =
            document.getElementById("contactSuccess");


        /* ================= CLEAR MESSAGES ================= */

        nameError.innerHTML = "";
        emailError.innerHTML = "";
        messageError.innerHTML = "";

        success.style.display = "none";


        let valid = true;


        /* ================= NAME VALIDATION ================= */

        if (name === "") {

            nameError.innerHTML =
                "Name is required";

            valid = false;
        }


        /* ================= EMAIL VALIDATION ================= */

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (email === "") {

            emailError.innerHTML =
                "Email is required";

            valid = false;

        } else if (!emailPattern.test(email)) {

            emailError.innerHTML =
                "Enter a valid email address";

            valid = false;
        }


        /* ================= MESSAGE VALIDATION ================= */

        if (message === "") {

            messageError.innerHTML =
                "Message is required";

            valid = false;

        } else if (message.length < 5) {

            messageError.innerHTML =
                "Message must contain at least 5 characters";

            valid = false;
        }


        /* ================= STOP IF INVALID ================= */

        if (!valid) {
            return;
        }


        /* ================= SEND DATA TO PHP ================= */

        try {

            const formData = new URLSearchParams();

            formData.append("name", name);
            formData.append("email", email);
            formData.append("message", message);


            const response = await fetch(
                "php/contact.php",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body: formData.toString()
                }
            );


            const data = await response.json();


            /* ================= PHP RESPONSE ================= */

            if (data.success) {

                success.className =
                    "alert alert-success mt-4";

                success.innerHTML =
                    "🎉 " + data.message;

                success.style.display =
                    "block";


                /* Clear form */

                contactForm.reset();


            } else {

                success.className =
                    "alert alert-danger mt-4";

                success.innerHTML =
                    "❌ " + data.message;

                success.style.display =
                    "block";
            }


        } catch (error) {

            console.error("Contact Error:", error);

            success.className =
                "alert alert-danger mt-4";

            success.innerHTML =
                "❌ Server connection error. Please check XAMPP.";

            success.style.display =
                "block";
        }

    });

}