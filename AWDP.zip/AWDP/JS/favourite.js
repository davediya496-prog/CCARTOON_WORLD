/* =====================================
   Cartoon World Favourite Cartoons
===================================== */


fetch("php/get_favourites.php")

    .then(response => {

        if (!response.ok) {
            throw new Error("Server error");
        }

        return response.json();

    })

    .then(data => {

        const favouriteData =
            document.getElementById("favouriteData");


        /* Check Login */

        if (!data.success) {

            favouriteData.innerHTML = `

                <div class="col-12 text-center">

                    <h3 class="text-danger">
                        🔒 ${data.message}
                    </h3>

                    <a
                        href="login.html"
                        class="btn btn-primary mt-3"
                    >
                        Login Now
                    </a>

                </div>

            `;

            return;
        }


        /* Check Favourite Data */

        if (data.data.length === 0) {

            favouriteData.innerHTML = `

                <div class="col-12 text-center">

                    <h3>
                        No Favourite Cartoons Yet ❤️
                    </h3>

                    <p>
                        Go to the cartoons page and
                        add your favourite cartoons.
                    </p>

                    <a
                        href="cartoons.html"
                        class="btn btn-warning"
                    >
                        Browse Cartoons 🎬
                    </a>

                </div>

            `;

            return;
        }


        /* Display Favourite Cartoons */

        let output = "";


        data.data.forEach(cartoon => {

            output += `

                <div class="col-lg-4 col-md-6">

                    <div class="card h-100 shadow">

                        <img
                            src="${cartoon.image}"
                            class="card-img-top"
                            alt="${cartoon.name}"
                        >

                        <div class="card-body text-center">

                            <h4>
                                ${cartoon.name}
                            </h4>

                            <h6 class="text-primary">
                                ${cartoon.category}
                            </h6>

                            <p>
                                ${cartoon.description}
                            </p>

                            <a
                                href="watch.html?cartoon=${encodeURIComponent(cartoon.name)}"
                                class="btn btn-warning"
                            >
                                Watch Now 🎬
                            </a>

                            <button
                                class="btn btn-danger mt-2"
                                onclick="removeFavourite(${cartoon.favorite_id}, this)"
                            >
                                ❌ Remove
                            </button>

                        </div>

                    </div>

                </div>

            `;

        });


        favouriteData.innerHTML = output;

    })


    .catch(error => {

        console.error(
            "Favourite Error:",
            error
        );

        document.getElementById(
            "favouriteData"
        ).innerHTML = `

            <div class="col-12 text-center">

                <h3 class="text-danger">
                    Unable to load favourites
                </h3>

                <p>
                    Please check XAMPP and database connection.
                </p>

            </div>

        `;

    });
    // ===============================
// Remove Favourite
// ===============================

function removeFavourite(favoriteId, button) {

    if (!confirm("Remove this cartoon from favourites?")) {
        return;
    }


    const formData = new URLSearchParams();

    formData.append(
        "favorite_id",
        favoriteId
    );


    fetch("php/remove_favourite.php", {

        method: "POST",

        headers: {
            "Content-Type":
                "application/x-www-form-urlencoded"
        },

        body: formData.toString()

    })

    .then(response => {

        if (!response.ok) {
            throw new Error("Server error");
        }

        return response.json();

    })

    .then(data => {

        if (data.success) {

            const card =
                button.closest(".col-lg-4");

            card.remove();

        } else {

            alert(data.message);

        }

    })

    .catch(error => {

        console.error(
            "Remove Favourite Error:",
            error
        );

        alert(
            "Server connection error. Please check XAMPP."
        );

    });

}