/* =====================================
   Fetch Cartoon Data From MySQL
===================================== */

fetch("php/cartoons.php")

    .then(response => {

        if (!response.ok) {
            throw new Error("Server error");
        }

        return response.json();

    })

    .then(data => {

        let output = "";

        if (data.length === 0) {

            output = `
                <div class="col-12">
                    <h3 class="text-center text-danger">
                        No cartoons found.
                    </h3>
                </div>
            `;

        } else {

            data.forEach(cartoon => {

                output += `

                    <div class="col-lg-4 col-md-6 mb-4">

                        <div class="card cartoon-card h-100">

                            <img
                                src="${cartoon.image}"
                                class="card-img-top"
                                alt="${cartoon.name}"
                            >

                            <div class="card-body text-center">

                                <h4>
                                    ${cartoon.name}
                                </h4>

                                <h6 class="text-primary">
                                    ${cartoon.category}
                                </h6>

                                <p>
                                    ${cartoon.description}
                                </p>

                                <a
                                    href="watch.html?cartoon=${encodeURIComponent(cartoon.name)}"
                                    class="btn btn-warning"
                                >
                                    Watch Now 🎬
                                </a>

                                <button
                                    class="btn btn-danger mt-2"
                                    onclick="favourite(this, ${cartoon.id})"
                                >
                                    ❤️ Favourite
                                </button>

                            </div>

                        </div>

                    </div>

                `;

            });

        }

        document.getElementById("cartoonData").innerHTML =
            output;

    })

    .catch(error => {

        console.error(
            "Error loading cartoons:",
            error
        );

        document.getElementById("cartoonData").innerHTML = `

            <div class="col-12">

                <h3 class="text-danger text-center">
                    Unable to load cartoons
                </h3>

                <p class="text-center">
                    Please check XAMPP and database connection.
                </p>

            </div>

        `;

    });