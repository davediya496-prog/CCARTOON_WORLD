/* =====================================
   Cartoon World Login
===================================== */

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function (event) {

        event.preventDefault();


        /* ================= GET VALUES ================= */

        const email =
            document.getElementById("loginEmail").value.trim();

        const password =
            document.getElementById("loginPassword").value;


        /* ================= ERROR ELEMENTS ================= */

        const emailError =
            document.getElementById("loginEmailError");

        const passwordError =
            document.getElementById("loginPasswordError");

        const loginMessage =
            document.getElementById("loginMessage");


        /* ================= CLEAR MESSAGES ================= */

        emailError.innerHTML = "";
        passwordError.innerHTML = "";

        loginMessage.style.display = "none";


        let valid = true;


        /* ================= EMAIL VALIDATION ================= */

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (email === "") {

            emailError.innerHTML =
                "Email is required";

            valid = false;

        } else if (!emailPattern.test(email)) {

            emailError.innerHTML =
                "Enter a valid email address";

            valid = false;
        }


        /* ================= PASSWORD VALIDATION ================= */

        if (password === "") {

            passwordError.innerHTML =
                "Password is required";

            valid = false;
        }


        /* ================= STOP IF INVALID ================= */

        if (!valid) {
            return;
        }


        /* ================= SEND TO PHP ================= */

        try {

            const formData = new URLSearchParams();

            formData.append("email", email);
            formData.append("password", password);


            const response = await fetch(
                "php/login.php",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body: formData.toString()
                }
            );


            const data = await response.json();


            /* ================= PHP RESPONSE ================= */

            if (data.success) {

                loginMessage.className =
                    "alert alert-success mt-4";

                loginMessage.innerHTML =
                    "✅ " + data.message;

                loginMessage.style.display =
                    "block";


                /* Redirect after successful login */

                setTimeout(function () {

                    window.location.href =
                        "index.html";

                }, 1500);


            } else {

                loginMessage.className =
                    "alert alert-danger mt-4";

                loginMessage.innerHTML =
                    "❌ " + data.message;

                loginMessage.style.display =
                    "block";
            }


        } catch (error) {

            console.error("Login Error:", error);

            loginMessage.className =
                "alert alert-danger mt-4";

            loginMessage.innerHTML =
                "❌ Server connection error. Please check XAMPP.";

            loginMessage.style.display =
                "block";
        }

    });

}