/* =====================================
   Cartoon World Dynamic Navbar
===================================== */

fetch("php/session.php")

    .then(response => response.json())

    .then(data => {

        const loginLink =
            document.getElementById("loginLink");

        const logoutLink =
            document.getElementById("logoutLink");

        const userLink =
            document.getElementById("userLink");


        if (data.loggedIn) {

            if (loginLink) {
                loginLink.style.display = "none";
            }

            if (logoutLink) {
                logoutLink.style.display = "block";
            }

            if (userLink) {

                userLink.innerHTML =
                    "👋 " + data.name;

                userLink.style.display =
                    "block";
            }

        } else {

            if (loginLink) {
                loginLink.style.display = "block";
            }

            if (logoutLink) {
                logoutLink.style.display = "none";
            }

            if (userLink) {
                userLink.style.display = "none";
            }

        }

    })

    .catch(error => {

        console.error(
            "Navbar Error:",
            error
        );

    });