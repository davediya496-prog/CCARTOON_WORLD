document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("registrationForm");

    form.addEventListener("submit", function (event) {

        event.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const mobile = document.getElementById("mobile").value.trim();
        const password = document.getElementById("password").value;
        const confirmPassword =
            document.getElementById("confirmPassword").value;

        document.getElementById("nameError").textContent = "";
        document.getElementById("emailError").textContent = "";
        document.getElementById("mobileError").textContent = "";
        document.getElementById("passwordError").textContent = "";
        document.getElementById("confirmPasswordError").textContent = "";

        const message =
            document.getElementById("successMessage");

        message.style.display = "none";

        let valid = true;

        if (name === "") {
            document.getElementById("nameError").textContent =
                "Please enter your name.";
            valid = false;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            document.getElementById("emailError").textContent =
                "Please enter a valid email.";
            valid = false;
        }

        if (!/^[0-9]{10}$/.test(mobile)) {
            document.getElementById("mobileError").textContent =
                "Enter exactly 10 digits.";
            valid = false;
        }

        if (password.length < 6) {
            document.getElementById("passwordError").textContent =
                "Password must be at least 6 characters.";
            valid = false;
        }

        if (password !== confirmPassword) {
            document.getElementById("confirmPasswordError").textContent =
                "Passwords do not match.";
            valid = false;
        }

        if (!valid) {
            return;
        }


        const formData = new FormData();

        formData.append("name", name);
        formData.append("email", email);
        formData.append("mobile", mobile);
        formData.append("password", password);


        fetch("php/register.php", {
            method: "POST",
            body: formData
        })

        .then(response => response.text())

        .then(result => {

            console.log("PHP RESPONSE:", result);

            let data;

            try {
                data = JSON.parse(result);
            }
            catch (error) {

                message.style.display = "block";
                message.className = "alert alert-danger mt-4";
                message.textContent =
                    "PHP Error: " + result;

                return;
            }


            message.style.display = "block";

            if (data.success) {

                message.className =
                    "alert alert-success mt-4";

                message.textContent =
                    data.message;

                form.reset();

            } else {

                message.className =
                    "alert alert-danger mt-4";

                message.textContent =
                    data.message;
            }

        })

        .catch(error => {

            console.error(error);

            message.style.display = "block";
            message.className =
                "alert alert-danger mt-4";

            message.textContent =
                "Unable to connect with PHP/database.";

        });

    });

});