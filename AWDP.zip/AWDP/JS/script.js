/* =====================================
   Cartoon World JavaScript
===================================== */


// ===============================
// Zoom In Cartoon Image
// ===============================

function zoomIn(){

    let image = document.getElementById("cartoonImage");

    image.style.transform = "scale(1.3)";

}


// ===============================
// Zoom Out Cartoon Image
// ===============================

function zoomOut(){

    let image = document.getElementById("cartoonImage");

    image.style.transform = "scale(1)";

}


// ===============================
// Change Background Theme
// ===============================

let backgroundIndex = 0;

let cartoonBackgrounds = [

    "linear-gradient(135deg,#ffecd2,#fcb69f)",

    "linear-gradient(135deg,#a1c4fd,#c2e9fb)",

    "linear-gradient(135deg,#fbc2eb,#a6c1ee)",

    "linear-gradient(135deg,#84fab0,#8fd3f4)",

    "linear-gradient(135deg,#fff1eb,#ace0f9)"

];


function changeBackground(){

    document.body.style.background =
        cartoonBackgrounds[backgroundIndex];

    backgroundIndex++;

    if(backgroundIndex >= cartoonBackgrounds.length){

        backgroundIndex = 0;

    }

}


// ===============================
// Switch Cartoon Images
// ===============================

let cartoonNumber = 1;


function switchCartoon(){

    let image = document.getElementById("cartoonImage");


    if(cartoonNumber === 1){

        image.src = "images/doraemon.jpg";

        cartoonNumber = 2;

    }

    else if(cartoonNumber === 2){

        image.src = "images/tomjerry.jpg";

        cartoonNumber = 3;

    }

    else{

        image.src = "images/mickey.jpg";

        cartoonNumber = 1;

    }

}


// ===============================
// Show Cartoon Facts
// ===============================

function showFacts(){

    document.getElementById("facts").style.display = "block";

}


// ===============================
// Hide Cartoon Facts
// ===============================

function hideFacts(){

    document.getElementById("facts").style.display = "none";

}


// ===============================
// Add Cartoon To Favourite
// ===============================

function favourite(button, cartoonId){

    if(!cartoonId){

        alert("Cartoon ID not found.");

        return;

    }


    const formData = new URLSearchParams();

    formData.append("cartoon_id", cartoonId);


    fetch("php/favourite.php", {

        method: "POST",

        headers: {
            "Content-Type":
                "application/x-www-form-urlencoded"
        },

        body: formData.toString()

    })

    .then(response => {

        if(!response.ok){

            throw new Error("Server error");

        }

        return response.json();

    })

    .then(data => {

        if(data.success){

            button.innerHTML =
                "❤️ Added to Favourite";

            button.style.background = "green";

            button.disabled = true;

        }

        else{

            alert(data.message);

        }

    })

    .catch(error => {

        console.error(
            "Favourite Error:",
            error
        );

        alert(
            "Server connection error. Please check XAMPP."
        );

    });

}


// ===============================
// Mouse Hover Effect
// ===============================

function imageHover(){

    document.getElementById("cartoonImage")
        .style.opacity = "0.7";

}


function imageLeave(){

    document.getElementById("cartoonImage")
        .style.opacity = "1";

}


// ===============================
// Page Load Event
// ===============================

window.onload = function(){

    console.log(
        "Cartoon World Loaded Successfully 🌈"
    );

};