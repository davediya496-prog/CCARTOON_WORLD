/* =====================================
   Cartoon World Registration Validation
===================================== */

const form = document.getElementById("registrationForm");

if (form) {

    form.addEventListener("submit", async function (event) {

        // Stop normal form submission
        event.preventDefault();


        /* ================= GET VALUES ================= */

        const name =
            document.getElementById("name").value.trim();

        const email =
            document.getElementById("email").value.trim();

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        const mobile =
            document.getElementById("mobile").value.trim();


        /* ================= ERROR ELEMENTS ================= */

        const nameError =
            document.getElementById("nameError");

        const emailError =
            document.getElementById("emailError");

        const passwordError =
            document.getElementById("passwordError");

        const confirmPasswordError =
            document.getElementById("confirmPasswordError");

        const mobileError =
            document.getElementById("mobileError");

        const successMessage =
            document.getElementById("successMessage");


        /* ================= CLEAR MESSAGES ================= */

        nameError.innerHTML = "";
        emailError.innerHTML = "";
        passwordError.innerHTML = "";
        confirmPasswordError.innerHTML = "";
        mobileError.innerHTML = "";

        successMessage.style.display = "none";


        let isValid = true;


        /* ================= NAME VALIDATION ================= */

        if (name === "") {

            nameError.innerHTML =
                "Name is required";

            isValid = false;
        }


        /* ================= EMAIL VALIDATION ================= */

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (email === "") {

            emailError.innerHTML =
                "Email is required";

            isValid = false;

        } else if (!emailPattern.test(email)) {

            emailError.innerHTML =
                "Enter a valid email address";

            isValid = false;
        }


        /* ================= PASSWORD VALIDATION ================= */

        // Minimum 8 characters
        // At least one uppercase
        // At least one lowercase
        // At least one number

        const passwordPattern =
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{8,}$/;

        if (password === "") {

            passwordError.innerHTML =
                "Password is required";

            isValid = false;

        } else if (!passwordPattern.test(password)) {

            passwordError.innerHTML =
                "Password must contain 8 characters, uppercase, lowercase and number";

            isValid = false;
        }


        /* ================= CONFIRM PASSWORD ================= */

        if (confirmPassword === "") {

            confirmPasswordError.innerHTML =
                "Confirm password is required";

            isValid = false;

        } else if (password !== confirmPassword) {

            confirmPasswordError.innerHTML =
                "Passwords do not match";

            isValid = false;
        }


        /* ================= MOBILE VALIDATION ================= */

        const mobilePattern =
            /^[0-9]{10}$/;

        if (mobile === "") {

            mobileError.innerHTML =
                "Mobile number is required";

            isValid = false;

        } else if (!mobilePattern.test(mobile)) {

            mobileError.innerHTML =
                "Enter valid 10 digit mobile number";

            isValid = false;
        }


        /* ================= STOP IF INVALID ================= */

        if (!isValid) {
            return;
        }


        /* ================= SEND DATA TO PHP ================= */

        try {

            const formData = new URLSearchParams();

            formData.append("name", name);
            formData.append("email", email);
            formData.append("mobile", mobile);
            formData.append("password", password);


            const response = await fetch(
                "php/register.php",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body: formData.toString()
                }
            );


            const data = await response.json();


            /* ================= PHP RESPONSE ================= */

            if (data.success) {

                successMessage.className =
                    "alert alert-success mt-4";

                successMessage.innerHTML =
                    "🎉 " + data.message;

                successMessage.style.display =
                    "block";


                // Clear form after successful registration
                form.reset();


                // Redirect to Login
                setTimeout(function () {

                    window.location.href =
                        "login.html";

                }, 2000);


            } else {

                successMessage.className =
                    "alert alert-danger mt-4";

                successMessage.innerHTML =
                    "❌ " + data.message;

                successMessage.style.display =
                    "block";
            }


        } catch (error) {

            console.error("Registration Error:", error);

            successMessage.className =
                "alert alert-danger mt-4";

            successMessage.innerHTML =
                "❌ Server connection error. Please check XAMPP.";

            successMessage.style.display =
                "block";
        }

    });

}