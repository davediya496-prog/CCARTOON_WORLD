<?php

header("Content-Type: application/json");

require_once "db.php";


/* ================= GET CARTOONS ================= */

$sql = "SELECT id, name, category, description, image
        FROM cartoons
        ORDER BY id ASC";


$result = $conn->query($sql);


$cartoons = [];


/* ================= STORE DATA ================= */

if ($result) {

    while ($row = $result->fetch_assoc()) {

        $cartoons[] = $row;
    }
}


/* ================= SEND JSON ================= */

echo json_encode($cartoons);


/* ================= CLOSE ================= */

$conn->close();
?>