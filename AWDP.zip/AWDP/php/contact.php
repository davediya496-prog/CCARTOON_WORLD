<?php

header("Content-Type: application/json");

require_once "db.php";


/* ================= REQUEST CHECK ================= */

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "success" => false,
        "message" => "Invalid request."
    ]);

    exit;
}


/* ================= GET DATA ================= */

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$message = trim($_POST["message"] ?? "");


/* ================= EMPTY CHECK ================= */

if ($name === "" || $email === "" || $message === "") {

    echo json_encode([
        "success" => false,
        "message" => "All fields are required."
    ]);

    exit;
}


/* ================= EMAIL CHECK ================= */

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid email address."
    ]);

    exit;
}


/* ================= MESSAGE LENGTH ================= */

if (strlen($message) < 5) {

    echo json_encode([
        "success" => false,
        "message" => "Message must contain at least 5 characters."
    ]);

    exit;
}


/* ================= INSERT MESSAGE ================= */

$stmt = $conn->prepare(
    "INSERT INTO contact_messages
    (name, email, message)
    VALUES (?, ?, ?)"
);

$stmt->bind_param(
    "sss",
    $name,
    $email,
    $message
);


/* ================= RESPONSE ================= */

if ($stmt->execute()) {

    echo json_encode([
        "success" => true,
        "message" => "Your message has been sent successfully!"
    ]);
} else {

    echo json_encode([
        "success" => false,
        "message" => "Failed to send message. Please try again."
    ]);
}


/* ================= CLOSE ================= */

$stmt->close();
$conn->close();
?>