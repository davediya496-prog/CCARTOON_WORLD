<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "cartoon_world";

// Connect to MySQL Server
$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    if (headers_sent() === false) {
        header("Content-Type: application/json");
    }
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed. Please make sure MySQL is running in XAMPP. Error: " . $conn->connect_error
    ]);
    exit;
}

// Auto-create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

if (!$conn->select_db($dbname)) {
    die("Unable to select database: " . $conn->error);
}

$conn->set_charset("utf8mb4");

// 1. Users Table
$conn->query("CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `mobile` VARCHAR(20) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// 2. Contact Messages Table
$conn->query("CREATE TABLE IF NOT EXISTS `contact_messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// 3. Cartoons Table
$conn->query("CREATE TABLE IF NOT EXISTS `cartoons` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `category` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `image` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// 4. Favorites Table
$conn->query("CREATE TABLE IF NOT EXISTS `favorites` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `cartoon_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`cartoon_id`) REFERENCES `cartoons`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `user_cartoon` (`user_id`, `cartoon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// Seed cartoons from data/cartoons.json if table is empty
$checkCartoons = $conn->query("SELECT COUNT(*) AS total FROM `cartoons`");
if ($checkCartoons) {
    $row = $checkCartoons->fetch_assoc();
    if (intval($row['total']) === 0) {
        $jsonFile = __DIR__ . "/../data/cartoons.json";
        if (file_exists($jsonFile)) {
            $jsonData = json_decode(file_get_contents($jsonFile), true);
            if (is_array($jsonData)) {
                $stmt = $conn->prepare("INSERT INTO `cartoons` (`name`, `category`, `description`, `image`) VALUES (?, ?, ?, ?)");
                foreach ($jsonData as $item) {
                    $cName = $item['name'] ?? '';
                    $cCat = $item['category'] ?? '';
                    $cDesc = trim($item['description'] ?? '');
                    $cImg = $item['image'] ?? '';
                    $stmt->bind_param("ssss", $cName, $cCat, $cDesc, $cImg);
                    $stmt->execute();
                }
                $stmt->close();
            }
        }
    }
}

?>