<?php

session_start();

header("Content-Type: application/json");

require_once "db.php";

/* Check Login */
if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "Please login first to manage favourites."
    ]);
    exit;
}

$user_id = $_SESSION["user_id"];

/* If POST request: Add to Favorites */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cartoon_id = intval($_POST["cartoon_id"] ?? 0);

    if ($cartoon_id <= 0) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid cartoon ID."
        ]);
        exit;
    }

    // Check if cartoon exists
    $cCheck = $conn->prepare("SELECT id FROM cartoons WHERE id = ?");
    $cCheck->bind_param("i", $cartoon_id);
    $cCheck->execute();
    if ($cCheck->get_result()->num_rows === 0) {
        echo json_encode([
            "success" => false,
            "message" => "Cartoon not found."
        ]);
        $cCheck->close();
        $conn->close();
        exit;
    }
    $cCheck->close();

    // Insert into favorites table
    $stmt = $conn->prepare("INSERT IGNORE INTO favorites (user_id, cartoon_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $cartoon_id);

    if ($stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Added to favourites!"
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Could not add to favourites."
        ]);
    }
    $stmt->close();
    $conn->close();
    exit;
}

/* If GET request: Retrieve Favorites */
$stmt = $conn->prepare(
    "SELECT
        favorites.id AS favorite_id,
        cartoons.id AS cartoon_id,
        cartoons.name,
        cartoons.category,
        cartoons.description,
        cartoons.image
     FROM favorites
     INNER JOIN cartoons ON favorites.cartoon_id = cartoons.id
     WHERE favorites.user_id = ?
     ORDER BY favorites.id DESC"
);

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$favourites = [];
while ($row = $result->fetch_assoc()) {
    $favourites[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $favourites
]);

$stmt->close();
$conn->close();
?>