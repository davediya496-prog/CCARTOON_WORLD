<?php

session_start();

header("Content-Type: application/json");

require_once "db.php";


/* ================= REQUEST CHECK ================= */

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "success" => false,
        "message" => "Invalid request."
    ]);

    exit;
}


/* ================= GET DATA ================= */

$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";


/* ================= EMPTY CHECK ================= */

if ($email === "" || $password === "") {

    echo json_encode([
        "success" => false,
        "message" => "Email and password are required."
    ]);

    exit;
}


/* ================= FIND USER ================= */

$stmt = $conn->prepare(
    "SELECT id, name, email, password
     FROM users
     WHERE email = ?"
);

$stmt->bind_param("s", $email);

$stmt->execute();

$result = $stmt->get_result();


/* ================= USER NOT FOUND ================= */

if ($result->num_rows === 0) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


/* ================= GET USER ================= */

$user = $result->fetch_assoc();


/* ================= PASSWORD CHECK ================= */

if (!password_verify($password, $user["password"])) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password."
    ]);

    $stmt->close();
    $conn->close();

    exit;
}


/* ================= CREATE SESSION ================= */

$_SESSION["user_id"] = $user["id"];
$_SESSION["user_name"] = $user["name"];
$_SESSION["user_email"] = $user["email"];


/* ================= SUCCESS ================= */

echo json_encode([
    "success" => true,
    "message" => "Login successful! Welcome " . $user["name"] . "."
]);


/* ================= CLOSE ================= */

$stmt->close();
$conn->close();
?>