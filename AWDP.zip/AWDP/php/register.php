<?php

session_start();

header("Content-Type: application/json");

require_once "db.php";

/* Check Request Method */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);
    exit;
}

/* Get Input Data */
$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$mobile = trim($_POST["mobile"] ?? "");
$password = $_POST["password"] ?? "";

/* Validation */
if (empty($name) || empty($email) || empty($mobile) || empty($password)) {
    echo json_encode([
        "success" => false,
        "message" => "All fields are required."
    ]);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid email address."
    ]);
    exit;
}

if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    echo json_encode([
        "success" => false,
        "message" => "Mobile number must be exactly 10 digits."
    ]);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 6 characters long."
    ]);
    exit;
}

/* Check if email is already registered */
$checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "This email is already registered. Please login instead."
    ]);
    $checkStmt->close();
    $conn->close();
    exit;
}
$checkStmt->close();

/* Hash Password and Insert User */
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users (name, email, mobile, password) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $mobile, $hashedPassword);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Registration successful! Welcome to Cartoon World 🎉 You can now login."
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Database error: Unable to complete registration. " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>
