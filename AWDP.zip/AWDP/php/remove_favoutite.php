<?php

session_start();

header("Content-Type: application/json");

require_once "db.php";


/* Check Login */

if (!isset($_SESSION["user_id"])) {

    echo json_encode([
        "success" => false,
        "message" => "Please login first."
    ]);

    exit;
}


$user_id = $_SESSION["user_id"];

$favorite_id = intval(
    $_POST["favorite_id"] ?? 0
);


/* Check Favorite ID */

if ($favorite_id <= 0) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid favourite."
    ]);

    exit;
}


/* Delete Favourite */

$stmt = $conn->prepare(
    "DELETE FROM favorites
     WHERE id = ?
     AND user_id = ?"
);


$stmt->bind_param(
    "ii",
    $favorite_id,
    $user_id
);


if ($stmt->execute()) {

    echo json_encode([
        "success" => true,
        "message" => "Favourite removed successfully."
    ]);
} else {

    echo json_encode([
        "success" => false,
        "message" => "Unable to remove favourite."
    ]);
}


$stmt->close();

$conn->close();
?>